VANTHEX LEGAL PAGES — SETUP

Files:
- index.html
- terms.html
- privacy.html

BEFORE PUBLISHING:
1. Open terms.html and privacy.html and replace:
   [INSERT SUPPORT SERVER INVITE OR CONTACT EMAIL]
   with a real support-server invite or contact email.
2. Check the privacy policy against what your bot actually stores, logs, and shares. Edit it if needed.
3. Upload all three HTML files to the root of a PUBLIC GitHub repository named vanthex-legal.
4. In GitHub: Settings > Pages > Deploy from a branch > main > /(root) > Save.
5. After publishing, your URLs will be:
   https://YOUR-GITHUB-USERNAME.github.io/vanthex-legal/
   https://YOUR-GITHUB-USERNAME.github.io/vanthex-legal/terms.html
   https://YOUR-GITHUB-USERNAME.github.io/vanthex-legal/privacy.html
6. In Discord Developer Portal > your app > General Information, put the terms URL in Terms of Service URL and the privacy URL in Privacy Policy URL.

These are starter templates and are not legal advice. Do not claim the bot collects no data unless you have verified that in its code/configuration.
